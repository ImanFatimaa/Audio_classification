% Function to detect pitch using Autocorrelation
function pitchFrequency = detectPitchAutocorr(audio, sampleRate)
    
    disp('--- AUTOCORRELATION ---'); % Display message indicating the start of Autocorrelation pitch detection
    
    % Step 1: Compute the autocorrelation of the signal
    [autocorrResult, lags] = xcorr(audio, 'coeff'); % Compute the autocorrelation of the audio signal
    
    % Keep only the positive lags (time delays in one direction)
    autocorrResult = autocorrResult(lags >= 0); % Keep autocorrelation values for positive lags
    lags = lags(lags >= 0); % Keep only the corresponding positive lags
    
    % Step 2: Define the valid lag range based on the desired pitch frequency range
    minLag = ceil(sampleRate / 2000); % Minimum lag for the highest pitch frequency (2000 Hz)
    maxLag = floor(sampleRate / 20);  % Maximum lag for the lowest pitch frequency (20 Hz)
    
    % Restrict the autocorrelation results to the valid lag range
    validAutocorr = autocorrResult(minLag:maxLag); % Select valid autocorrelation values
    validLags = lags(minLag:maxLag); % Select corresponding valid lags
    
    % Step 3: Find the peak within the valid lag range
    [~, peakIdx] = max(validAutocorr); % Find the index of the maximum autocorrelation value
    pitchPeriod = validLags(peakIdx) / sampleRate; % Calculate pitch period in seconds
    pitchFrequency = 1 / pitchPeriod; % Convert pitch period to frequency in Hz
    
    % Display the detected pitch frequency
    fprintf('Pitch Frequency (Autocorrelation): %.2f Hz\n', pitchFrequency);

    % Step 4: Plot the valid autocorrelation results
    % Create a plot of autocorrelation values against lag (in seconds)
    % figure; % Create a new figure
    % plot(validLags / sampleRate, validAutocorr); % Plot the valid autocorrelation values
    % title('Autocorrelation of the Signal (Valid Range)'); % Add title to the plot
    % xlabel('Lag (s)'); % Label the x-axis as "Lag (s)"
    % ylabel('Autocorrelation Coefficient'); % Label the y-axis as "Autocorrelation Coefficient"
end
