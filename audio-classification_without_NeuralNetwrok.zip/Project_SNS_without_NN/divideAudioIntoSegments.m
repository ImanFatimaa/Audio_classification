% Function to divide audio into segments
function [segments, numSegments] = divideAudioIntoSegments(audio, sampleRate, segmentDuration)
    segmentLength = segmentDuration * sampleRate; % Calculate the number of samples in each segment
    numSegments = floor(length(audio) / segmentLength); % Calculate how many segments the audio will be divided into
    
    % Initialize cell array to store segments
    segments = cell(1, numSegments); 
    
    % Loop to extract each segment
    for i = 1:numSegments
        startIdx = (i - 1) * segmentLength + 1; % Calculate the start index of the segment
        endIdx = i * segmentLength; % Calculate the end index of the segment
        segments{i} = audio(startIdx:endIdx); % Store the segment in the cell array
    end
end