% Step 1: Extract audio files using uigetfile or audioDatastore
% uigetfile options a dialogue box in our case conssiting of the files having .wav extension present
% where multiselect is on it means you an select multi files from the path
% dialogue box is provided with a default name of select audio files 
% filenames stores the file selected while path stores the path of the directory where selected file is present

[fileNames, path] = uigetfile('*.wav', 'Select Audio Files', 'MultiSelect', 'on');
% if selected file by user is a single file it is converted into array because in case of single selection uigetfunction returns only a string
%in order to deal with ulti selection and single selection smoothly we need to convert single filelocation into array

if ischar(fileNames)
    fileNames = {fileNames};
end

% Step 2: Call classify_audio for the original audio
% we caled the classify_audio function for classifying the file selected by user present at specified folder.
% classify audio function returns the information about original category and original features of file selected
 
[originalFeatures, originalCategory] = classify_audio(fileNames, path);

% Step 3: Add noise to audio and call classify_audio for noisy audio
% according to the requiremennt we need to add noise in the signals from noise models
% we chosed two noise models Rayleigh and Nakagami-m
% Rayleigh: it adds noise on the basis that there is no visible sight of path between reciever and transmitter mostly in wirless communication
% Nakagami_m: Nakagami_m involves the both less and high level scattering making ensure that noise is added on basis of if sound travels from ubran to city or vuce versa

noiseModels = {'Rayleigh', 'Nakagami-m'};

% snr value defines how noisy is the environment based on levels high level less noise
%snrValues = [10, 20, 30]; % SNR levels
snrValues = [5, 30]; % SNR levels
% the loop iterates through each noise model and SNR value combination
% after iteration it prints the current noise model and SNR level for reference

for noiseIdx = 1:length(noiseModels)
    for snrIdx = 1:length(snrValues)
        fprintf('\nTesting with %s Noise Model at SNR: %d dB\n', noiseModels{noiseIdx}, snrValues(snrIdx));
        
        % Step 3a: Add noise to the audio files based on the noise model and SNR
        % noise will be added in the model and will be saved in the new file 
        noisyFileNames = fileNames;  % Keep the same files (only noise will be added)
        
        % Manually add noise to the files
        % we manually added noise in the audio present at specified path by continously iterating over the path array
        for i = 1:length(fileNames)
            [audio, fs] = audioread(fullfile(path, fileNames{i}));
            audio = mean(audio, 2);  % Convert to mono if stereo
        % after adding noise in the model on the basis of resoective snr for the respective model 
            noisyAudio = addNoise(audio, noiseModels{noiseIdx}, snrValues(snrIdx));
            
            % Save the noisy audio to a temporary file (or just process it directly)

            audiowrite(fullfile(path, ['noisy_' fileNames{i}]), noisyAudio, fs);

      % adding noise at the start of filename to diff between noisy and original audio
            noisyFileNames{i} = ['noisy_' fileNames{i}];  % Update the filename to point to noisy audio
        end
      % after adding noise in the model we called the classify audio function to classify audio after adding noise features in it
        % Step 3b: Call classify_audio for the noisy audio
        [noisyFeatures, noisyCategory] = classify_audio(noisyFileNames, path);
        
    % results of the audio classification after and before adding noise based on the features like
    % zero crossing rate : low for less noise and high for noisy models
    % energy: total power of signal in given period, calculated by taking square of amplitudes in given period high energy louder sound
    % rms: square root of the average of the squared amplitude values, rms represents the effective value or magnitude of the signal
    % spectral centroid: the center of gravity of the spectrum, where majority of signalis centered 
    % high spectral centoid sharp sound and dull sound has less centered frequences
    % high spectral bandwidth is associated with noise while lessspectral bandwidth is associated with harmonic sounds
        % Step 3c: Compare results (ZCR, Energy, Spectral Centroid, and Labels)
        for i = 1:length(fileNames)
            fprintf('File: %s\n', fileNames{i});
            fprintf('\tOriginal: Category: %s, ZCR: %.4f, Energy: %.4f, Spectral Centroid: %.4f Hz, RMS Value: %.4f\n', ...
                    originalCategory{i}, originalFeatures(i, 1), originalFeatures(i, 2), originalFeatures(i, 3), originalFeatures(i, 4));
            
            fprintf('\tNoisy: Category: %s, ZCR: %.4f, Energy: %.4f, Spectral Centroid: %.4f Hz, RMS Value: %.4f\n\n', ...
                     noisyCategory{i}, noisyFeatures(i, 1), noisyFeatures(i, 2), noisyFeatures(i, 3), noisyFeatures(i, 4));
end
    end
end

%-------------------------------FUNCTIONS---------------------------------
% Function to add noise 
% in this function we are adding noise by choosing a specific model for example rayleigh model is chosen from main 
% with respective snr wre added noise in the audio

function noisy_audio = addNoise(audio, noiseModel, snr)
    % Function to add noise based on the specified model and SNR
% we checked here if the model chosen is raleigh and nakagami_m
% we only selected two models in our case

    noise = [];
    switch noiseModel
 
        case 'Rayleigh'
            noise = rayleighNoise(length(audio), snr);
        case 'Nakagami-m'
            noise = nakagamiNoise(length(audio), snr);
        otherwise
            error('Unknown noise model.');
    end
    noisy_audio = audio + noise;
end

% Nested function for Rayleigh noise
% nested loop for raleigh model noise adding in audio 
% we wrotethe function definedfrom its formula for raleigh model and added the noise
function noise = rayleighNoise(len, snr)
    noise = sqrt(randn(len, 1).^2 + randn(len, 1).^2) * 10^(-snr/20);
end

% Nested function for Nakagami-m noise
function noise = nakagamiNoise(len, snr)

% nested loop for Nakagami-m model noise adding in audio 
% we wrotethe function definedfrom its formula for Nakagami-m model and added the noise

    m = 1;  % Nakagami m parameter
    noise = sqrt(gamrnd(m, 1, [len, 1])) * 10^(-snr/20);
end

