function analyzePitchDetection(audio, sampleRate, segmentDuration)
    % Function to analyze pitch detection using Autocorrelation, Cepstrum, and AMDF methods
    % Divide audio into segments
    [segments, numSegments] = divideAudioIntoSegments(audio, sampleRate, segmentDuration);

    % Initialize arrays to store pitch results
    pitchAutocorr = zeros(1, numSegments); % Autocorrelation results
    pitchCepstrum = zeros(1, numSegments); % Cepstrum results
    pitchAMDF = zeros(1, numSegments);     % AMDF results

    % Loop through each segment
    for i = 1:numSegments
        % Extract the current segment
        segment = segments{i};

        % Apply pitch detection methods
        pitchAutocorr(i) = detectPitchAutocorr(segment, sampleRate); % Autocorrelation
        pitchCepstrum(i) = detectPitchCepstrum(segment, sampleRate); % Cepstrum
        pitchAMDF(i) = detectPitchAMDF(segment, sampleRate);         % AMDF
    end

    % Display results
    fprintf('\n--- Pitch Detection Results ---\n');
    disp('Autocorrelation Method:');
    disp(pitchAutocorr);
    disp('Cepstrum Method:');
    disp(pitchCepstrum);
    disp('AMDF Method:');
    disp(pitchAMDF);

    % Plot pitch frequencies for comparison
    figure;
    hold on;
    plot(1:numSegments, pitchAutocorr, '-o', 'DisplayName', 'Autocorrelation');
    plot(1:numSegments, pitchCepstrum, '-x', 'DisplayName', 'Cepstrum');
    plot(1:numSegments, pitchAMDF, '-s', 'DisplayName', 'AMDF');
    title('Pitch Detection Results Across Segments');
    xlabel('Segment Index');
    ylabel('Pitch Frequency (Hz)');
    legend;
    grid on;
    hold off;

    % Compare methods based on standard deviation
    [bestMethod, ~] = comparePitchMethods(pitchAutocorr, pitchCepstrum, pitchAMDF);

    % Display the best method
    fprintf('\nBest Method: %s\n', bestMethod);
end