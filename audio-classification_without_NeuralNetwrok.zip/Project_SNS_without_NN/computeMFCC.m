 % This function computes the Mel Frequency Cepstral Coefficients (MFCCs) 
  % from an audio signal. The MFCCs are commonly used in speech and audio 
  % processing to represent the spectral properties of an audio signal

function mfccs = computeMFCC(audio, sampleRate)
    % --- MFCC Computation ---
    disp('--- MFCC Computation ---');

    numMelFilters = 26;      % Number of Mel filters (typically between 20 and 40)
    numMFCCs = 13;           % Number of MFCC coefficients to extract (usually 12 or 13)
    windowSize = 400;        % Length of each frame in samples
    hopSize = 160;           % Distance between consecutive frames 

    window = hamming(windowSize, 'periodic');  % Hamming window to taper the frame edges

    % calculate the number of frames in the audio signal
    numFrames = floor((length(audio) - windowSize) / hopSize) + 1;

    % storing the stft results in the matrix
    stftMatrix = zeros(windowSize, numFrames);

    % Compute the Short-Time Fourier Transform (STFT) for each frame
    for i = 1:numFrames
        startIdx = (i - 1) * hopSize + 1;
        endIdx = startIdx + windowSize - 1;
        frame = audio(startIdx:endIdx);
        stftMatrix(:, i) = fft(frame .* window, windowSize);
    end
    % Compute the power spectrum (magnitude squared of the STFT)
    % keeping only the positive frequencies

    powerSpectrum = abs(stftMatrix(1:windowSize/2+1, :)).^2;
   % Generate the Mel filter bank to map linear frequencies to Mel scale
    melFilterBank = melFilterBankGenerator(numMelFilters, sampleRate, windowSize);

   % Apply the Mel filter bank to the power spectrum to get the Mel spectrum
    melSpectrum = melFilterBank * powerSpectrum;

    % Apply logarithmic compression to the Mel spectrum for better feature representation
    logMelSpectrum = log(melSpectrum + eps);

    % Perform Discrete Cosine Transform (DCT) to decorrelate the Mel features
    mfccs = dct(logMelSpectrum);
 
    % Keep only the first 'numMFCCs' coefficients 
    mfccs = mfccs(1:numMFCCs, :);

    disp('MFCCs (First Frame):');
    disp(mfccs(:, 1));

    % figure;
    % imagesc(mfccs);
    % axis xy;
    % title('Mel Frequency Cepstral Coefficients (MFCCs)');
    % xlabel('Frame Index');
    % ylabel('MFCC Index');
    % colorbar;
end
%--------------------------------------------------------------------------
    % Function to generate the Mel filter bank
    function melFilterBank = melFilterBankGenerator(numFilters, fs, nfft)

    % Frequency limits: 0 Hz to Nyquist frequency (half of the sample rate)
    lowFreq = 0;
    highFreq = fs / 2;

    % Convert frequencies to Mel scale
    lowMel = 2595 * log10(1 + lowFreq / 700);  % Mel scale conversion for low frequency
    highMel = 2595 * log10(1 + highFreq / 700);  % Mel scale conversion for high frequency

    % Linearly spaced Mel scale points (for the filter centers)
    melPoints = linspace(lowMel, highMel, numFilters + 2);
    hzPoints = 700 * (10.^(melPoints / 2595) - 1);  % Convert Mel points back to Hz

    % Calculate corresponding FFT bin points for each Mel filter
    binPoints = floor((nfft + 1) * hzPoints / fs);  % Convert Hz points to FFT bins
    binPoints = max(binPoints, 1);  % Ensure bins are not below 1
    binPoints = min(binPoints, nfft / 2);  % Ensure bins do not exceed Nyquist frequency

    % Initialize the Mel filter bank
    melFilterBank = zeros(numFilters, floor(nfft / 2 + 1));

    % Create triangular Mel filters
    for i = 1:numFilters
        startBin = binPoints(i);  % Start bin of the current filter
        endBin = binPoints(i + 1);  % End bin of the current filter
        
        % Fill in the filter values from 0 to 1 for the first half
        if startBin < endBin
            melFilterBank(i, startBin:endBin) = linspace(0, 1, endBin - startBin + 1);
            % Fill in the filter values from 1 to 0 for the second half
            if i < numFilters
                melFilterBank(i, endBin:binPoints(i+2)) = linspace(1, 0, binPoints(i+2) - endBin + 1);
            end
        end
    end
end
