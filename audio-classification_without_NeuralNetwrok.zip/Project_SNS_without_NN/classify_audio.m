% audio classification function which is called in main function for classification of audio on basis of different function
% after feeding path and file name in function we get categories and features of that specific file
 
function [features, category] = classify_audio(fileNames,path )
    
    % Initialize arrays for features and labels
    features = [];
    labels = {}; % Assuming labels are in the file names (e.g., Speech_1.wav)

    sampleRate = 16000; % Target sample rate for uniformity

    % Step 1: Feature Extraction from the file 
    for i = 1:length(fileNames)
        % Read audio file
        [audio, fs] = audioread(fullfile(path, fileNames{i}));

         % Plottig original audio
        figure;
        subplot(1, 1, 1);
        plot(audio);
        title('Original Audio Signal');
        xlabel('Sample');
        ylabel('Amplitude');
        
        audio = mean(audio, 2); % convert to mono if stereo
        
        % Normalize audio on range of -1:1
        audio = audio / max(abs(audio));
        % Short-Time Fourier Transform (STFT) is a technique used to analyze non-stationary signals
        % non-stationary signals (signals whose frequency content changes over time) by breaking them into short segments or windows.
        % Parameters for STFT
        % window length tells us how many samples in one frame and how much resolution of requency in each segment depending on the window length
        % high window length means specific samples with more resolution
        % overlap value tells overlapping of windows frames
        % 1024 is standard ensuring that window has enough frequency data

        windowLength = 1024; % Length of each window for STFT

        % 512 overlaps is standard value ensuring that their is no loss of important info while overlapping

        overlap = 512; % Overlap between windows
        
        % Calculate STFT-spectogram
        % this spectogram computes the spectrum of audio signal 
        % and gets information about signal in both frequency and time( time bins respective to columns of spectrum axis) ensuring good analysis
        
        [S, F, T] = spectrogram(audio, windowLength, overlap, windowLength, fs);
        % zero crossing rate : low for less noise and high for noisy models
        % energy: total power of signal in given period, calculated by taking square of amplitudes in given period high energy louder sound
        % rms: square root of the average of the squared amplitude values, rms represents the effective value or magnitude of the signal
        % spectral centroid: the center of gravity of the spectrum, where majority of signalis centered 
        % high spectral centoid sharp sound and dull sound has less centered frequences

        % Time-domain features
        zcr = mean(abs(diff(audio > 0))); % Zero Crossing Rate
        energy = sum(audio.^2); % Energy
        
        % Spectral Features
        % Spectral Centroid (Calculated from the STFT)
        spectralCentroid = sum(F .* sum(abs(S).^2, 2)) / sum(sum(abs(S).^2, 2));
 
        % Root Mean Square Value
        rmsValue = sqrt(mean(audio.^2));                          
 
        % Store features according to stft
        features = [features; zcr, energy, spectralCentroid, rmsValue];
        labels{end+1} = fileNames{i}; % Replace with actual label extraction if available
        
        %--------------------STEP 2:APPLYING DIGITAL FEATURES---------------------
       % Resample audio to desired sample rate
       % The resample function adjusts the sample rate of the audio signal. 

       % If the audio file's sample rate (fs) is different from the target sample rate (sampleRate),
       % it resamples the audio signal to match the target sample rate, ensuring uniformity
       % across all audio files and making them comparable for feature extraction.
        if fs ~= sampleRate
            audio = resample(audio, sampleRate, fs);
            fs = sampleRate;
        end

        % Low-pass filter
        % A low-pass filter allows frequencies below a specified cutoff frequency to pass through,
        % while attenuating higher frequencies. In this case, the cutoff frequency is set to 3000 Hz
        % This filter removes high-frequency noise or unwanted components that are above 3000 Hz

        lpFilt = designfilt('lowpassiir', 'FilterOrder', 8, 'HalfPowerFrequency', 3000, 'SampleRate', sampleRate);
        lowPassAudio = filtfilt(lpFilt, audio);

        % 'lowpassiir' specifies that the filter should be a low-pass Infinite Impulse Response filter
        % 'FilterOrder' is set to 8, indicating the complexity of the filter
        % 'HalfPowerFrequency' is the cutoff frequency
        % 'SampleRate' is the desired sample rate of the audio signal after resampling
        % filtfilt applies the filter to the audio signal using zero-phase filtering (by processing the signal in both directions).
        % This helps avoid phase distortion, ensuring that the filtered audio signal retains its original timing.

        % High-pass filter
        % A high-pass filter allows frequencies above a specified cutoff frequency to pass through,
        % while attenuating lower frequencies. In this case, the cutoff frequency is set to 300 Hz
        % This filter removes low-frequency noise or unwanted components

        hpFilt = designfilt('highpassiir', 'FilterOrder', 8, 'HalfPowerFrequency', 300, 'SampleRate', sampleRate);
        highPassAudio = filtfilt(hpFilt, audio);

        % Band-pass filter
        % A band-pass filter allows frequencies within a specified range to pass through while attenuating frequencies outside this range
        % In this case, the filter allows frequencies between 300 Hz and 3000 Hz to pass through
        % This filter is useful when we want to focus on a particular frequency range, for example, the speech frequency range
                
        bpFilt = designfilt('bandpassiir', 'FilterOrder', 8, 'HalfPowerFrequency1', 300,'HalfPowerFrequency2', 3000, 'SampleRate', sampleRate);
        bandPassAudio = filtfilt(bpFilt, audio);
        % 'bandpassiir' specifies a band-pass filter.
        % 'HalfPowerFrequency1' is set to 300 Hz (the lower bound of the pass band)
        % 'HalfPowerFrequency2' is set to 3000 Hz (the upper bound of the pass band)
        % This filter allows frequencies in the range of 300 Hz to 3000 Hz to pass through and attenuates frequencies outside this range

        % figure;
        % % Plot filtered signals
        % subplot(3, 1, 1);
        % plot(lowPassAudio);
        % title('Low-Pass Filtered Signal');
        % xlabel('Sample');
        % ylabel('Amplitude');
        % 
        % subplot(3, 1, 2);
        % plot(highPassAudio);
        % title('High-Pass Filtered Signal');
        % xlabel('Sample');
        % ylabel('Amplitude');
        % 
        % subplot(3, 1, 3);
        % plot(bandPassAudio);
        % title('Band-Pass Filtered Signal');
        % xlabel('Sample');
        % ylabel('Amplitude');
        
        % disp('Playing the original sound file...');
        % sound(audio, fs);
        % pause(6); 
        % 
        % disp('Playing the LP file...');
        % sound(lowPassAudio, fs);
        % pause(2);
        % 
        % disp('Playing the HP file...');
        % sound(highPassAudio, fs);
        % pause(2);    
        % 
        % disp('Playing the BP file...');
        % sound(bandPassAudio, fs);
        % pause(2);

%------------PITCH DETECTION AND FREQUENCY--------------------
% Pitch detection is an essential step in analyzing audio signals, especially for distinguishing speech or music
% It helps in identifying the fundamental frequency (pitch) of the audio signal, which is useful for classification

% Call pitch detection functions

% Autocorrelation measures the similarity between a signal and a time-shifted version of itself
% It's commonly used for detecting periodicity and is effective for estimating pitch in speech or musical signals
% The AMDF is a method used for detecting the pitch of speech or musical signals by comparing the magnitude difference between the signal and time-shifted versions.
% It's another approach to pitch detection that is known for its simplicity and effectiveness, particularly in noisy environments.
% The cepstrum is obtained by taking the inverse Fourier transform of the logarithm of the spectrum of a signal.
% It's particularly useful for detecting pitch in both voiced and unvoiced speech, and music signals.

        pitchFrequencyAutocorr = detectPitchAutocorr(audio, sampleRate);
        pitchFrequencyCepstrum = detectPitchCepstrum(audio, sampleRate);
        pitchFrequencyAMDF = detectPitchAMDF(audio, sampleRate);

% Call MFCC computation
% MFCC is a commonly used feature extraction technique in speech processing. It captures the timbral texture of the sound, which is highly useful in speech, music, and environmental sound recognition.
% MFCCs, which are a representation of the short-term power spectrum of the sound, typically used for classification tasks.

        mfccs = computeMFCC(audio, sampleRate);
        
    end

    % Step 2: Classification
    % classifying the audios based on thresholds deined
    % Define thresholds (Adjust based on dataset analysis)
    zcrThreshold_1 = 0.1;         %Example threshold for ZCR
    zcrThreshold_2 = 0.02;
    energyThreshold_noise = 5000; % Example threshold for Energy
    spectralCentroidThreshold = 500; % Hz (Example)

    % Classify based on features
    category = cell(length(fileNames), 1);
    for i = 1:length(fileNames)
        if (zcrThreshold_2 < features(i, 1) && features(i, 1) < zcrThreshold_1) && (features(i, 3) < spectralCentroidThreshold) 
            category{i} = 'Speech';
        elseif (features(i, 1) > zcrThreshold_1) && (features(i, 3) > spectralCentroidThreshold) 
            category{i} = 'Music';
        elseif (features(i, 1) < zcrThreshold_2) && (features(i,3) < energyThreshold_noise)
            category{i} = 'Noise';
        end
    end
end
 
