% Function to compare pitch detection methods based on standard deviation
function [bestMethod, bestMethodIdx] = comparePitchMethods(pitchAutocorr, pitchCepstrum, pitchAMDF)
    % Calculate the standard deviation for each method
    autocorrStd = std(pitchAutocorr); 
    cepstrumStd = std(pitchCepstrum); 
    amdfStd = std(pitchAMDF); 

    % Display the standard deviations
    fprintf('\n--- Consistency Analysis ---\n');
    fprintf('Autocorrelation Std Dev: %.2f Hz\n', autocorrStd); 
    fprintf('Cepstrum Std Dev: %.2f Hz\n', cepstrumStd); 
    fprintf('AMDF Std Dev: %.2f Hz\n', amdfStd); 

    % Identify the best method based on the lowest standard deviation
    [~, bestMethodIdx] = min([autocorrStd, cepstrumStd, amdfStd]); % Find the method with the lowest standard deviation
    methods = {'Autocorrelation', 'Cepstrum', 'AMDF'}; % List of methods
    
    % Return the best method and its index
    bestMethod = methods{bestMethodIdx};
end