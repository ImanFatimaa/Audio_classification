function noisy_categories = testNoisySignals(audio, trainedNet, noiseModels, snrValues, numCoeffs, fs)
    % Function to add noise to audio signals and classify them using the trained network.
    
    %here we are using two loop bcx we have 2 noise model which are further expanded to more than 1 snr value
    %Loop through noise models and SNR levels
    for noiseIdx = 1:length(noiseModels)
        for snrIdx = 1:length(snrValues)
            fprintf('\nTesting with %s Noise Model at SNR: %d dB\n', noiseModels{noiseIdx}, snrValues(snrIdx));

                %calling the created functiion to add noise to the original
                %audio to test network
                noisy_audio = addNoise(audio, noiseModels{noiseIdx}, snrValues(snrIdx));
                
                %plotting the noisy signal with noise model and snr
                figure;
                subplot(1, 1, 1);
                plot(noisy_audio);
                title(sprintf('Noisy Audio Signal - %s Noise, SNR: %d dB', noiseModels{noiseIdx}, snrValues(snrIdx)));
                xlabel('Sample');
                ylabel('Amplitude');
                
                %calling the common function we used for original audio that extracts feautures of audio signal, but this the
                %audio is noised by models given and the labeling the sound on basis of mfcc and network
                audio_classification(trainedNet,noisy_audio,fs,numCoeffs);

                %just a dotted line for clear visibilty and seperation of each model
              fprintf('\n----------------------------------------------------------\n'); 
        end
    end
end
