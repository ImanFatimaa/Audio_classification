%---------------------PROMPT TO TRAIN NEURAL NETWORK-----------------------
%we used feedforward neural network(FNN) and train to classify sound into
%three required categories

%path to dataset folder, we extracted some of the signals from urban8k
%dataset 
dataFolder = 'D:\Iqra\SEM 5\SNS\Project\Audiofilesfortest';
numCoeffs = 13;         %we defined no of MFCC coefficients we will be using

%Training the Model from complete dataset
trainedNet = trainModel(dataFolder, numCoeffs);

%---------------------------CODE STARTS HERE------------------------------
%passing a sample audio signal to get iits label
%path for sample audio  file
testAudioFile = 'D:\Iqra\SEM 5\SNS\Project\Audiofilesfortest\Noise\noise.wav';  

%Loading the sample audio file
[audio, fs] = audioread(testAudioFile);  % Read audio file and sample rate
sampleRate=16000;

%ploting original audio
figure;
subplot(1, 1, 1);
plot(audio);
title('Original Audio Signal');
xlabel('Sample');
ylabel('Amplitude');

%along with plotting the original signal we are also playing it for better understanding
disp('Playing the original sound file...'); 
sound(audio, fs);
pause(6);

audio = mean(audio, 2); % Convert to mono if stereo

% Resample audio to desired sample rate
% The resample function adjusts the sample rate of the audio signal.
% If the audio file's sample rate (fs) is different from the target sample rate (sampleRate),
% it resamples the audio signal to match the target sample rate, ensuring uniformity
% across all audio files and making them comparable for feature extraction.
 if fs ~= sampleRate
       audio = resample(audio, sampleRate, fs);
       fs = sampleRate;
 end

%--------------------------BAND PASS FILTERS------------------------------
%calling a function to generate all band pass filters
   BPF(audio,sampleRate);

%----------------------PITCH DETECTION AND MFCC---------------------------
%Pitch detection is an essential step in analyzing audio signals, especially for distinguishing speech or music
%It helps in identifying the fundamental frequency (pitch) of the audio signal, which is useful for classification

%Call pitch detection functions

%Autocorrelation measures the similarity between a signal and a time-shifted version of itself
%It's commonly used for detecting periodicity and is effective for estimating pitch in speech or musical signals
%The AMDF is a method used for detecting the pitch of speech or musical signals by comparing the magnitude difference between the signal and time-shifted versions.
%It's another approach to pitch detection that is known for its simplicity and effectiveness, particularly in noisy environments.
%The cepstrum is obtained by taking the inverse Fourier transform of the logarithm of the spectrum of a signal.
%It's particularly useful for detecting pitch in both voiced and unvoiced speech, and music signals.

       segmentDuration = 0.5; % Duration of each segment in seconds (each segment will be 0.5 seconds long)
       analyzePitchDetection(audio, sampleRate, segmentDuration);

%We then also added a function to compare all the pitch detection algorithm
%we used to find accuracy and robustness in methos
        comparePitchMethods(pitchAutocorr, pitchCepstrum, pitchAMDF);

%Call MFCC computation
%MFCC is a commonly used feature extraction technique in speech processing. It captures the timbral texture of the sound, which is highly useful in speech, music, and environmental sound recognition.
%MFCCs, which are a representation of the short-term power spectrum of the sound, typically used for classification tasks.

        mfccs = computeMFCC(audio, sampleRate);

%--------------------------AUDIO CLASSIFICATION---------------------------

%results being displayed in the function
        audio_classification(trainedNet,audio,fs,numCoeffs);

%----------------------------NOISE ADDITION-------------------------------
%first calling the function to add noise into the model audio
% according to the requiremennt we need to add noise in the signals from noise models
% we chosed two noise models Rayleigh and Nakagami-m
% Rayleigh: it adds noise on the basis that there is no visible sight of path between reciever and transmitter mostly in wirless communication
% Nakagami_m: Nakagami_m involves the both less and high level scattering making ensure that noise is added on basis of if sound travels from ubran to city or vuce versa

noiseModels = {'Rayleigh', 'Nakagami-m'};

% snr value defines how noisy is the environment based on levels high level less noise
%snrValues = [10, 20, 30]; % SNR levels
snrValues = [5, 30]; % SNR levels

%we create a seperate function which will work in loop to get data for
%multiple noisy signals
fprintf('\nTesting with Noise Models %d dB\n');
testNoisySignals(audio, trainedNet, noiseModels, snrValues, numCoeffs, fs);