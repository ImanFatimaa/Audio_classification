% Function to detect pitch using Cepstrum
function pitchFrequency = detectPitchCepstrum(audio, sampleRate)
    
    disp('--- CEPSTRUM ---'); % Display message indicating the start of Cepstrum pitch detection
    
    % Step 1: Compute the cepstrum
    cepstrum = real(ifft(log(abs(fft(audio))))); % Compute the cepstrum of the audio signal
    
    % Step 2: Generate the quefrency axis
    quefrency = (0:length(cepstrum)-1) / sampleRate; % Create the quefrency axis in seconds
    
    % Step 3: Set a starting index for pitch search
    startIdx = ceil(sampleRate / 40); % Minimum pitch frequency of 40 Hz
    
    % Error handling: Check if the starting index is valid
    if startIdx > length(cepstrum) % If the start index exceeds the length of the cepstrum
        error('Start index exceeds cepstrum length. Check your parameters.'); % Show an error message
    end
    
    % Step 4: Find the maximum cepstrum value after the start index
    [~, qIdx] = max(cepstrum(startIdx:end)); % Find the maximum cepstrum value in the valid range
    
    % Step 5: Calculate the corresponding index in the full quefrency range
    finalIdx = qIdx + startIdx - 1; % Adjust the index to the full quefrency range
    
    % Error handling: Ensure the final index does not exceed quefrency length
    if finalIdx > length(quefrency) % If the final index exceeds the quefrency length
        warning('Calculated quefrency index exceeds the length of the quefrency array. Adjusting to the maximum index.'); % Show a warning
        finalIdx = length(quefrency); % Adjust to the maximum index
    end
    
    % Step 6: Calculate the pitch frequency
    pitchQuefrency = quefrency(finalIdx); % Get the quefrency corresponding to the maximum cepstrum value
    pitchFrequency = 1 / pitchQuefrency; % Convert quefrency to pitch frequency in Hz
    
    % Display the detected pitch frequency
    fprintf('Pitch Frequency (Cepstrum): %.2f Hz\n', pitchFrequency);
    
    % Step 7: Plot the cepstrum
    % figure; % Create a new figure
    % plot(quefrency, cepstrum); % Plot the cepstrum against quefrency
    % title('Cepstrum of the Signal'); % Add title to the plot
    % xlabel('Quefrency (s)'); % Label the x-axis as "Quefrency (s)"
    % ylabel('Cepstrum Amplitude'); % Label the y-axis as "Cepstrum Amplitude"
end

