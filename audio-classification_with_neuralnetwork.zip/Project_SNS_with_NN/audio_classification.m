function res = audio_classification(trainedNet,audio,fs,numCoeffs)
%Extracting MFCC features for the sample audio using built-in function 
features = mfcc(audio, fs, 'NumCoeffs', numCoeffs);  

%Reduce to a fixed-size vector 
fixedSizeFeatures = mean(features, 1);

%Truncate or pad to match numCoeffs if sample audio has diff mfcc's
if size(fixedSizeFeatures, 2) ~= numCoeffs
    fixedSizeFeatures = fixedSizeFeatures(:, 1:numCoeffs); % Ensure correct size
end

%Normalize the features to match training process
fixedSizeFeatures = normalize(fixedSizeFeatures);
%Classify audio using the trained network
YPred = classify(trainedNet, fixedSizeFeatures);  

%Display the predicted label
disp('Predicted label for the sample test audio:');
switch char(YPred)
    case 'Speech'
        disp('The audio is classified as Speech.');
    case 'Noise'
        disp('The audio is classified as Noise.');
    case 'Music'
        disp('The audio is classified as Music.');
    otherwise
        disp('Unknown label.');
end
end