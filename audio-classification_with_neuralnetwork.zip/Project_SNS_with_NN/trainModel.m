%-----------------------TRAINING SCRIPT (trainModel.m)--------------------------

function net = trainModel(dataFolder, numCoeffs)
    % Step 1: Load Dataset
    ads = audioDatastore(dataFolder, 'IncludeSubfolders', true, 'LabelSource','foldernames');
    
    % Step 2: Split Dataset
    [adsTrain, adsValidation, adsTest] = splitEachLabel(ads, 0.7, 0.2, 0.1, 'randomize');
    
    % Step 3: Extract Features for Training Data
    trainFeatures = zeros(0, numCoeffs); % Initialize dimensions
    trainLabels = [];
    
    while hasdata(adsTrain)
        [audio, info] = read(adsTrain);
        fs = info.SampleRate;
       
        % Extract MFCC features
        features = mfcc(audio, fs, 'NumCoeffs', numCoeffs);
        
        % Reduce variable-length features to a fixed-size vector (mean pooling)
        fixedSizeFeatures = mean(features, 1);
        if size(fixedSizeFeatures, 2) ~= numCoeffs
            fixedSizeFeatures = fixedSizeFeatures(:, 1:numCoeffs); % Truncate or pad to match numCoeffs
        end
        
        % Concatenate features and labels
        trainFeatures = [trainFeatures; fixedSizeFeatures];
        trainLabels = [trainLabels; info.Label];
    end
    
    % Normalize Features
    trainFeatures = normalize(trainFeatures);
    trainLabels = categorical(trainLabels); % Convert labels to categorical format
    
    % Step 4: Define Neural Network
    numClasses = numel(unique(trainLabels)); % Determine the number of unique classes
    layers = [
        featureInputLayer(size(trainFeatures, 2))
        fullyConnectedLayer(64)
        reluLayer
        fullyConnectedLayer(numClasses) % Match the number of unique classes
        softmaxLayer
        classificationLayer];
    
    % Training Options
    options = trainingOptions('adam', ...
        'InitialLearnRate', 0.001, ...
        'MaxEpochs', 20, ...
        'MiniBatchSize', 64, ...
        'ValidationData', {trainFeatures, trainLabels}, ...
        'Plots', 'training-progress', ...
        'Verbose', false);
    
    % Step 5: Train the Network
    net = trainNetwork(trainFeatures, trainLabels, layers, options);
end
