% Function to add noise 
% in this function we are adding noise by choosing a specific model for example rayleigh model is chosen from main 
% with respective snr wre added noise in the audio

function noisy_audio = addNoise(audio, noiseModel, snr)
    % Function to add noise based on the specified model and SNR
% we checked here if the model chosen is raleigh and nakagami_m
% we only selected two models in our case

    noise = [];
    switch noiseModel
 
        case 'Rayleigh'
            noise = rayleighNoise(length(audio), snr);
        case 'Nakagami-m'
            noise = nakagamiNoise(length(audio), snr);
        otherwise
            error('Unknown noise model.');
    end
    noisy_audio = audio + noise;
end

%-------------------------------------------------------------------------
% Nested function for Rayleigh noise
% nested loop for raleigh model noise adding in audio 
% we wrotethe function definedfrom its formula for raleigh model and added the noise
function noise = rayleighNoise(len, snr)
    noise = sqrt(randn(len, 1).^2 + randn(len, 1).^2) * 10^(-snr/20);
end

%----------------------------------------------------------------------
% Nested function for Nakagami-m noise
function noise = nakagamiNoise(len, snr)

% nested loop for Nakagami-m model noise adding in audio 
% we wrotethe function definedfrom its formula for Nakagami-m model and added the noise

    m = 1;  % Nakagami m parameter
    noise = sqrt(gamrnd(m, 1, [len, 1])) * 10^(-snr/20);
end

