% Function to detect pitch using AMDF
function pitchFrequency = detectPitchAMDF(audio, sampleRate)
    
    disp('--- AMDF ---'); % Display message indicating the start of AMDF pitch detection
    
    % Step 1: Initialize variables
    signalLength = length(audio); % Get the length of the audio signal
    amdf = zeros(1, signalLength); % Initialize an array to store AMDF values
    
    % Step 2: Compute the AMDF
    for lag = 1:signalLength % Loop through each lag (time shift)
        amdf(lag) = sum(abs(audio(1:end-lag+1) - audio(lag:end))); % Calculate the AMDF for the current lag
    end
    
    % Step 3: Determine the pitch period from the AMDF
    % Define the search range corresponding to pitch frequencies between 20 Hz and 2000 Hz
    searchStart = ceil(sampleRate / 2000); % Minimum lag for 2000 Hz
    searchEnd = ceil(sampleRate / 20);    % Maximum lag for 20 Hz
    
    % Find the lag corresponding to the minimum AMDF value in the search range
    [~, amdfIdx] = min(amdf(searchStart:searchEnd)); % Find the index of the minimum AMDF value
    amdfIdx = amdfIdx + searchStart - 1; % Adjust index to full AMDF array
    
    % Calculate the pitch period and convert to pitch frequency
    pitchPeriod = amdfIdx / sampleRate;  % Pitch period in seconds
    pitchFrequency = 1 / pitchPeriod;   % Pitch frequency in Hz
    
    % Display the detected pitch frequency
    fprintf('Pitch Frequency (AMDF): %.2f Hz\n', pitchFrequency);
    
    % Step 4: Plot the AMDF
    % figure; % Create a new figure
    % plot((1:signalLength) / sampleRate, amdf); % Plot the AMDF against lag (in seconds)
    % title('Average Magnitude Difference Function (AMDF)'); % Add title to the plot
    % xlabel('Lag (s)'); % Label the x-axis as "Lag (s)"
    % ylabel('AMDF Value'); % Label the y-axis as "AMDF Value"
end
